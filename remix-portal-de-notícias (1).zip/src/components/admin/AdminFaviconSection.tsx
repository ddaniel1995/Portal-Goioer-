import React, { useState, useRef } from 'react';
import { 
  Globe, 
  Upload, 
  Download, 
  Copy, 
  Check, 
  ExternalLink, 
  Sparkles, 
  Search, 
  RotateCcw, 
  CheckCircle2, 
  FileCode, 
  Laptop, 
  Smartphone,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { 
  faviconService, 
  FAVICON_PRESETS, 
  DEFAULT_FAVICON_SVG 
} from '../../services/faviconService';

interface AdminFaviconSectionProps {
  faviconUrl: string;
  onFaviconChange: (url: string) => void;
  siteName: string;
  primaryColor: string;
  logoColorUrl?: string;
  onSave?: () => void;
}

export const AdminFaviconSection: React.FC<AdminFaviconSectionProps> = ({
  faviconUrl,
  onFaviconChange,
  siteName,
  primaryColor,
  logoColorUrl,
  onSave,
}) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'url' | 'presets' | 'monogram' | 'instructions'>('upload');
  const [urlInput, setUrlInput] = useState(faviconUrl.startsWith('data:') ? '' : faviconUrl);
  const [monogramLetter, setMonogramLetter] = useState(siteName ? siteName.trim()[0] || 'P' : 'P');
  const [monogramBg, setMonogramBg] = useState(primaryColor || '#dc2626');
  const [copiedCode, setCopiedCode] = useState(false);
  const [liveTestMessage, setLiveTestMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // Apply live test to current browser tab
  const handleTestInBrowser = () => {
    faviconService.applyFavicon(faviconUrl);
    setLiveTestMessage('Favicon aplicado com sucesso na sua aba do navegador!');
    setTimeout(() => setLiveTestMessage(null), 3500);
  };

  // Handle file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size (< 2MB)
    if (file.size > 2 * 1024 * 1024) {
      setErrorMessage('O arquivo de imagem deve ter no máximo 2MB.');
      setTimeout(() => setErrorMessage(null), 4000);
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      if (dataUrl) {
        onFaviconChange(dataUrl);
        faviconService.applyFavicon(dataUrl);
        setErrorMessage(null);
        setLiveTestMessage('Favicon carregado e atualizado na aba com sucesso!');
        setTimeout(() => setLiveTestMessage(null), 3500);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Handle URL submit
  const handleUrlSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;

    onFaviconChange(urlInput.trim());
    faviconService.applyFavicon(urlInput.trim());
    setLiveTestMessage('Favicon vinculado por URL aplicado na aba!');
    setTimeout(() => setLiveTestMessage(null), 3500);
  };

  // Handle Logo to Favicon
  const handleUsePortalLogo = () => {
    if (logoColorUrl && logoColorUrl.trim()) {
      onFaviconChange(logoColorUrl.trim());
      faviconService.applyFavicon(logoColorUrl.trim());
      setLiveTestMessage('Favicon atualizado com a Logo do Portal!');
      setTimeout(() => setLiveTestMessage(null), 3500);
    } else {
      // Generate from default portal logo style
      const generated = faviconService.generateLetterFavicon(siteName[0] || 'P', primaryColor || '#dc2626');
      onFaviconChange(generated);
      faviconService.applyFavicon(generated);
      setLiveTestMessage('Favicon gerado a partir do emblema do portal!');
      setTimeout(() => setLiveTestMessage(null), 3500);
    }
  };

  // Handle Monogram Generation
  const handleGenerateMonogram = () => {
    const generated = faviconService.generateLetterFavicon(monogramLetter, monogramBg);
    onFaviconChange(generated);
    faviconService.applyFavicon(generated);
    setLiveTestMessage(`Monograma com a letra "${monogramLetter.toUpperCase()}" gerado e aplicado!`);
    setTimeout(() => setLiveTestMessage(null), 3500);
  };

  // Handle Preset Select
  const handleSelectPreset = (svgUri: string, presetName: string) => {
    onFaviconChange(svgUri);
    faviconService.applyFavicon(svgUri);
    setLiveTestMessage(`Preset "${presetName}" aplicado com sucesso!`);
    setTimeout(() => setLiveTestMessage(null), 3500);
  };

  // Handle Reset to Default
  const handleResetDefault = () => {
    onFaviconChange('/favicon.svg');
    faviconService.applyFavicon('/favicon.svg');
    setLiveTestMessage('Favicon restaurado para o padrão original!');
    setTimeout(() => setLiveTestMessage(null), 3500);
  };

  // Handle Download File for GitHub repo
  const handleDownloadFile = async () => {
    setIsDownloading(true);
    try {
      await faviconService.downloadFavicon(faviconUrl, 'favicon.png');
      setLiveTestMessage('Download do arquivo favicon.png iniciado!');
      setTimeout(() => setLiveTestMessage(null), 3500);
    } catch (err) {
      console.error(err);
    } finally {
      setIsDownloading(false);
    }
  };

  // Handle Copy HTML Code
  const handleCopyCode = () => {
    const code = faviconService.generateHtmlSnippet(
      faviconUrl.startsWith('data:') ? '/favicon.svg' : faviconUrl
    );
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 3000);
  };

  const currentDisplayUrl = faviconUrl || DEFAULT_FAVICON_SVG;

  return (
    <div className="bg-white p-6 sm:p-8 rounded-2xl border border-slate-200/80 shadow-xs space-y-6">
      {/* Header */}
      <div className="border-b border-slate-100 pb-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-red-50 text-red-600 flex items-center justify-center">
              <Globe className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <span>Favicon do Site (Vercel & GitHub)</span>
                <span className="text-[10px] uppercase font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-emerald-600" />
                  Sincronizado
                </span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Altere o ícone que identifica o portal nas abas do navegador, favoritos, atalhos de celular e resultados do Google.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleTestInBrowser}
            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            title="Atualiza a aba do navegador agora para visualizar"
          >
            <Laptop className="w-3.5 h-3.5 text-slate-600" />
            <span>Testar na Aba Agora</span>
          </button>

          <button
            type="button"
            onClick={handleResetDefault}
            className="px-2.5 py-1.5 text-xs text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
            title="Restaurar favicon padrão"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Restaurar Padrão</span>
          </button>
        </div>
      </div>

      {/* Notifications */}
      {liveTestMessage && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold rounded-xl flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{liveTestMessage}</span>
        </div>
      )}

      {errorMessage && (
        <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-xs font-semibold rounded-xl flex items-center gap-2 animate-fadeIn">
          <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Interactive Live Browser Mockup & Preview */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Interactive Mockups */}
        <div className="lg:col-span-6 space-y-4">
          <div className="bg-slate-900 p-4 rounded-xl shadow-md border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-[11px] text-slate-400 font-semibold border-b border-slate-800 pb-2">
              <span className="flex items-center gap-1.5 text-slate-300">
                <Laptop className="w-3.5 h-3.5 text-red-400" />
                Simulador de Aba do Navegador (Chrome / Safari / Edge)
              </span>
              <span className="text-[10px] text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-1.5 py-0.5 rounded">
                Live Preview
              </span>
            </div>

            {/* Browser Tab Mockup */}
            <div className="bg-slate-800/90 rounded-t-lg p-2 flex items-center justify-between border-b border-slate-700">
              <div className="flex items-center gap-2 max-w-[280px]">
                {/* Traffic lights */}
                <div className="flex items-center gap-1.5 mr-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                </div>

                {/* Tab Pill */}
                <div className="bg-slate-900 text-slate-200 px-3 py-1 rounded-md text-xs font-medium flex items-center gap-2 shadow-inner border border-slate-700/60">
                  <img
                    src={currentDisplayUrl}
                    alt="Favicon"
                    className="w-4 h-4 rounded-xs shrink-0 object-contain"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = DEFAULT_FAVICON_SVG;
                    }}
                  />
                  <span className="truncate max-w-[130px] font-semibold text-slate-100 text-[11px]">
                    {siteName || 'Portal de Notícias'}
                  </span>
                  <span className="text-slate-500 text-[10px] hover:text-white cursor-pointer ml-1">×</span>
                </div>
              </div>

              <div className="text-[10px] text-slate-400 font-mono hidden sm:inline">
                + Nova Guia
              </div>
            </div>

            {/* Address Bar */}
            <div className="bg-slate-950 px-3 py-1.5 rounded-lg flex items-center gap-2 text-xs text-slate-300 font-mono">
              <div className="w-3.5 h-3.5 text-emerald-400 shrink-0">🔒</div>
              <span className="text-slate-500">https://</span>
              <span className="text-white font-semibold">portal-noticias.vercel.app</span>
              <span className="text-slate-500">/</span>
            </div>
          </div>

          {/* Google Search Result Preview */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
            <div className="text-[11px] font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Search className="w-3.5 h-3.5 text-blue-600" />
              <span>Como seu Favicon aparece no Google</span>
            </div>

            <div className="bg-white p-3 rounded-lg border border-slate-200/80 space-y-1">
              <div className="flex items-center gap-2 text-xs">
                <div className="w-6 h-6 rounded-full bg-slate-100 border border-slate-200 p-0.5 flex items-center justify-center shrink-0">
                  <img
                    src={currentDisplayUrl}
                    alt="Google Favicon"
                    className="w-4 h-4 rounded-full object-contain"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = DEFAULT_FAVICON_SVG;
                    }}
                  />
                </div>
                <div className="flex flex-col">
                  <span className="text-[11px] font-semibold text-slate-900 leading-tight">
                    {siteName || 'Portal de Notícias'}
                  </span>
                  <span className="text-[10px] text-slate-500 leading-none">
                    https://portal-noticias.vercel.app
                  </span>
                </div>
              </div>
              <div className="text-sm font-semibold text-blue-800 hover:underline cursor-pointer">
                {siteName} - Jornalismo, Notícias de Hoje e Última Hora
              </div>
              <p className="text-[11px] text-slate-600 line-clamp-2">
                Acompanhe em tempo real as últimas notícias de política, economia, esporte, cultura e o guia de empresas.
              </p>
            </div>
          </div>

          {/* Real Size Visualizations */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
            <div className="text-[11px] font-bold text-slate-700 mb-2">Escalas em Alta Resolução:</div>
            <div className="flex items-center gap-4">
              <div className="flex flex-col items-center gap-1">
                <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 p-1 flex items-center justify-center shadow-xs">
                  <img src={currentDisplayUrl} alt="16px" className="w-4 h-4 object-contain" />
                </div>
                <span className="text-[9px] font-mono text-slate-500">16x16</span>
              </div>

              <div className="flex flex-col items-center gap-1">
                <div className="w-10 h-10 rounded-lg bg-white border border-slate-200 p-1 flex items-center justify-center shadow-xs">
                  <img src={currentDisplayUrl} alt="32px" className="w-8 h-8 object-contain" />
                </div>
                <span className="text-[9px] font-mono text-slate-500">32x32</span>
              </div>

              <div className="flex flex-col items-center gap-1">
                <div className="w-12 h-12 rounded-lg bg-white border border-slate-200 p-1 flex items-center justify-center shadow-xs">
                  <img src={currentDisplayUrl} alt="48px" className="w-10 h-10 object-contain" />
                </div>
                <span className="text-[9px] font-mono text-slate-500">48x48</span>
              </div>

              <div className="flex flex-col items-center gap-1">
                <div className="w-14 h-14 rounded-xl bg-white border border-slate-200 p-1.5 flex items-center justify-center shadow-xs">
                  <img src={currentDisplayUrl} alt="Apple Touch" className="w-11 h-11 object-contain rounded-lg" />
                </div>
                <span className="text-[9px] font-mono text-slate-500">Apple/iOS</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Management Controls */}
        <div className="lg:col-span-6 space-y-4">
          {/* Sub-tabs */}
          <div className="flex border-b border-slate-200 text-xs font-bold gap-1 overflow-x-auto pb-1">
            <button
              type="button"
              onClick={() => setActiveTab('upload')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'upload'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Fazer Upload</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('url')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'url'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>URL Externa</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('presets')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'presets'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Presets Prontos</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('monogram')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'monogram'
                  ? 'bg-red-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <span className="font-serif font-black text-xs">A</span>
              <span>Monograma</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('instructions')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeTab === 'instructions'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <FileCode className="w-3.5 h-3.5 text-amber-400" />
              <span>Vercel & GitHub</span>
            </button>
          </div>

          {/* Tab 1: Upload File */}
          {activeTab === 'upload' && (
            <div className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
              <div>
                <span className="text-xs font-bold text-slate-800 block mb-1">
                  Selecione o arquivo de ícone do seu computador
                </span>
                <p className="text-[11px] text-slate-500">
                  Formatos aceitos: <strong>.ico, .png, .svg, .jpg, .webp</strong>. Recomendamos imagem quadrada (ex: 64x64 ou 512x512 pixels).
                </p>
              </div>

              <input
                type="file"
                ref={fileInputRef}
                accept=".ico,.png,.svg,.jpg,.jpeg,.webp,image/*"
                onChange={handleFileUpload}
                className="hidden"
              />

              <div className="flex flex-col sm:flex-row gap-2">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-all cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  <span>Escolher Arquivo do Computador...</span>
                </button>

                <button
                  type="button"
                  onClick={handleUsePortalLogo}
                  className="px-4 py-2.5 bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  title="Gera o favicon a partir da imagem da logo configurada no portal"
                >
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>Usar Logo do Portal</span>
                </button>
              </div>
            </div>
          )}

          {/* Tab 2: External URL */}
          {activeTab === 'url' && (
            <form onSubmit={handleUrlSubmit} className="p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-800 block mb-1">
                  URL Direta do Favicon (GitHub, Vercel Blob ou CDN)
                </label>
                <p className="text-[11px] text-slate-500 mb-2">
                  Cole uma URL pública permanente (ex: link do arquivo bruto no GitHub raw ou repositório público).
                </p>
                <div className="flex gap-2">
                  <input
                    type="url"
                    value={urlInput}
                    onChange={(e) => setUrlInput(e.target.value)}
                    placeholder="https://raw.githubusercontent.com/.../public/favicon.ico"
                    className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-red-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
                  >
                    Vincular URL
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* Tab 3: Presets */}
          {activeTab === 'presets' && (
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
              <span className="text-xs font-bold text-slate-800 block">
                Escolha um ícone profissional pré-configurado:
              </span>
              <div className="grid grid-cols-2 gap-2.5">
                {FAVICON_PRESETS.map((preset) => (
                  <div
                    key={preset.id}
                    onClick={() => handleSelectPreset(preset.svgDataUri, preset.name)}
                    className="p-3 bg-white hover:bg-red-50/50 border border-slate-200 hover:border-red-400 rounded-xl cursor-pointer transition-all flex items-center gap-3 group"
                  >
                    <div className="w-10 h-10 rounded-lg bg-slate-100 p-1 flex items-center justify-center shrink-0 border border-slate-200 group-hover:scale-105 transition-transform">
                      <img src={preset.svgDataUri} alt={preset.name} className="w-7 h-7 object-contain" />
                    </div>
                    <div className="overflow-hidden">
                      <h5 className="text-xs font-bold text-slate-900 group-hover:text-red-600 truncate">
                        {preset.name}
                      </h5>
                      <p className="text-[10px] text-slate-500 line-clamp-1">{preset.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Tab 4: Monogram */}
          {activeTab === 'monogram' && (
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
              <span className="text-xs font-bold text-slate-800 block">
                Gerador de Monograma Vetorial (Inicial do Portal)
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Letra / Inicial do Portal
                  </label>
                  <input
                    type="text"
                    maxLength={2}
                    value={monogramLetter}
                    onChange={(e) => setMonogramLetter(e.target.value.toUpperCase())}
                    className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-center text-base font-black text-slate-900 uppercase"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-slate-600 mb-1">
                    Cor de Fundo do Favicon
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={monogramBg}
                      onChange={(e) => setMonogramBg(e.target.value)}
                      className="w-10 h-9 p-0.5 rounded-lg border border-slate-200 cursor-pointer bg-white"
                    />
                    <input
                      type="text"
                      value={monogramBg}
                      onChange={(e) => setMonogramBg(e.target.value)}
                      className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-800"
                    />
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={handleGenerateMonogram}
                className="w-full py-2.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>Gerar e Aplicar Monograma SVG</span>
              </button>
            </div>
          )}

          {/* Tab 5: Instructions for Vercel & GitHub */}
          {activeTab === 'instructions' && (
            <div className="p-4 rounded-xl bg-slate-900 text-slate-200 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-bold text-white flex items-center gap-1.5">
                  <FileCode className="w-4 h-4 text-amber-400" />
                  Vínculo com Vercel & GitHub
                </span>
                <span className="text-[10px] text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                  Deploy Automático
                </span>
              </div>

              <div className="space-y-2 text-[11px] text-slate-300 leading-relaxed">
                <p>
                  <strong>1. Em Tempo Real no Navegador:</strong> Qualquer alteração feita aqui no Painel ADM já passa a valer imediatamente no site carregado no navegador!
                </p>
                <p>
                  <strong>2. No Repositório GitHub:</strong> Para que o favicon seja o arquivo padrão do seu código-fonte, basta clicar no botão <strong>"Baixar Arquivo Favicon"</strong> abaixo e colocá-lo na pasta <code className="bg-slate-800 px-1 rounded text-amber-300">public/</code> do seu repositório.
                </p>
                <p>
                  <strong>3. No Deploy da Vercel:</strong> Quando você faz o push no GitHub, a Vercel compila a pasta <code className="bg-slate-800 px-1 rounded text-amber-300">public/</code> automaticamente e distribui o favicon por CDN mundial.
                </p>
              </div>

              {/* Code snippet */}
              <div>
                <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1 font-mono">
                  <span>Tags configuradas no index.html:</span>
                  <button
                    type="button"
                    onClick={handleCopyCode}
                    className="text-amber-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
                  >
                    {copiedCode ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedCode ? 'Copiado!' : 'Copiar Tags'}</span>
                  </button>
                </div>
                <pre className="p-2.5 bg-slate-950 rounded-lg text-[10px] text-slate-300 font-mono overflow-x-auto border border-slate-800">
                  {faviconService.generateHtmlSnippet(faviconUrl.startsWith('data:') ? '/favicon.svg' : faviconUrl)}
                </pre>
              </div>
            </div>
          )}

          {/* Action Row: Download & Commit Helper */}
          <div className="p-3 bg-slate-100 rounded-xl border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center p-1 shrink-0">
                <img src={currentDisplayUrl} alt="Atual" className="w-5 h-5 object-contain" />
              </div>
              <div className="text-left">
                <span className="text-xs font-bold text-slate-800 block">
                  Exportar para GitHub / Vercel
                </span>
                <span className="text-[10px] text-slate-500">
                  Baixe o arquivo pronto para a pasta public/
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={handleDownloadFile}
                disabled={isDownloading}
                className="flex-1 sm:flex-none px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 shadow-xs transition-colors cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 text-amber-400" />
                <span>{isDownloading ? 'Gerando...' : 'Baixar favicon.png'}</span>
              </button>

              {onSave && (
                <button
                  type="button"
                  onClick={onSave}
                  className="flex-1 sm:flex-none px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 shadow-xs transition-colors cursor-pointer"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Salvar Tudo</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
