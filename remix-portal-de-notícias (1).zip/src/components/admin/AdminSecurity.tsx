import React, { useState, useEffect } from 'react';
import { 
  Users, 
  UserPlus, 
  KeyRound, 
  User, 
  Lock, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  AlertCircle, 
  Trash2, 
  Edit3, 
  RotateCcw, 
  ShieldCheck, 
  ShieldAlert,
  Save,
  X,
  Plus
} from 'lucide-react';
import { storageService } from '../../services/storageService';
import { AdminUser } from '../../types';
import { ConfirmModal } from '../common/ConfirmModal';

interface AdminSecurityProps {
  onRefresh?: () => void;
}

export const AdminSecurity: React.FC<AdminSecurityProps> = ({ onRefresh }) => {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  
  // Form State
  const [username, setUsername] = useState('');
  const [name, setName] = useState('');
  const [role, setRole] = useState<'admin' | 'editor'>('admin');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Form Mode
  const [isFormOpen, setIsFormOpen] = useState(false);

  // Modals & Feedback
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [userToDelete, setUserToDelete] = useState<AdminUser | null>(null);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const loadUsers = () => {
    const list = storageService.getAdminUsers();
    setUsers(list);
  };

  useEffect(() => {
    loadUsers();

    const handleUsersUpdate = () => {
      loadUsers();
    };

    window.addEventListener('portal_admin_users_updated', handleUsersUpdate);
    return () => {
      window.removeEventListener('portal_admin_users_updated', handleUsersUpdate);
    };
  }, []);

  const resetForm = () => {
    setEditingUserId(null);
    setUsername('');
    setName('');
    setRole('admin');
    setPassword('');
    setConfirmPassword('');
    setShowPassword(false);
    setShowConfirmPassword(false);
    setIsFormOpen(false);
  };

  const handleStartCreate = () => {
    resetForm();
    setIsFormOpen(true);
    setStatusMessage(null);
  };

  const handleStartEdit = (user: AdminUser) => {
    setEditingUserId(user.id);
    setUsername(user.username);
    setName(user.name || user.username);
    setRole(user.role || 'admin');
    setPassword(user.password);
    setConfirmPassword(user.password);
    setIsFormOpen(true);
    setStatusMessage(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    const cleanUsername = username.trim();
    const cleanPassword = password.trim();

    if (!cleanUsername) {
      setStatusMessage({ type: 'error', text: 'Por favor, informe o nome de usuário.' });
      return;
    }

    if (cleanUsername.length < 3) {
      setStatusMessage({ type: 'error', text: 'O nome de usuário deve ter pelo menos 3 caracteres.' });
      return;
    }

    if (!cleanPassword) {
      setStatusMessage({ type: 'error', text: 'Por favor, informe a senha para o usuário.' });
      return;
    }

    if (cleanPassword !== confirmPassword.trim()) {
      setStatusMessage({ type: 'error', text: 'A senha e a confirmação de senha não conferem.' });
      return;
    }

    const res = storageService.saveAdminUser({
      id: editingUserId || undefined,
      username: cleanUsername,
      name: name.trim() || cleanUsername,
      role,
      password: cleanPassword
    });

    if (res.success) {
      setStatusMessage({ type: 'success', text: res.message });
      loadUsers();
      resetForm();
      if (onRefresh) onRefresh();
      setTimeout(() => setStatusMessage(null), 4000);
    } else {
      setStatusMessage({ type: 'error', text: res.message });
    }
  };

  const handleConfirmDelete = () => {
    if (!userToDelete) return;
    const res = storageService.deleteAdminUser(userToDelete.id);
    setUserToDelete(null);

    if (res.success) {
      setStatusMessage({ type: 'success', text: res.message });
      loadUsers();
      if (editingUserId === userToDelete.id) {
        resetForm();
      }
      if (onRefresh) onRefresh();
      setTimeout(() => setStatusMessage(null), 4000);
    } else {
      setStatusMessage({ type: 'error', text: res.message });
    }
  };

  const handleRestoreDefaults = () => {
    storageService.resetDefaultAdminUsers();
    loadUsers();
    resetForm();
    setShowResetConfirm(false);
    setStatusMessage({
      type: 'success',
      text: 'Usuário padrão restaurado com sucesso! Usuário: @Daniel1995 / Senha: 1010'
    });
    if (onRefresh) onRefresh();
    setTimeout(() => setStatusMessage(null), 5000);
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-5xl mx-auto pb-12">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-950 text-white p-6 sm:p-8 rounded-2xl shadow-md flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-600/20 text-red-400 border border-red-500/30 text-xs font-bold uppercase tracking-wider mb-2">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Gestão de Acesso & Segurança</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight">
            Controle de Usuários e Senhas
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 mt-2 max-w-2xl leading-relaxed">
            Gerencie os usuários do sistema. Altere login e senha, cadastre novos operadores ou redefina as credenciais para o padrão de fábrica.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={handleStartCreate}
            className="px-4 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>Novo Usuário</span>
          </button>
          
          <button
            onClick={() => setShowResetConfirm(true)}
            className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white rounded-xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 cursor-pointer border border-slate-700"
            title="Restaurar usuário padrão @Daniel1995"
          >
            <RotateCcw className="w-4 h-4 text-amber-400" />
            <span>Restaurar Padrão</span>
          </button>
        </div>
      </div>

      {/* Default user info card */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 sm:p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-amber-100 text-amber-800 shrink-0">
            <KeyRound className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-amber-900">
              Credenciais Padrão do Sistema
            </h4>
            <p className="text-xs text-amber-800 mt-0.5">
              Usuário: <span className="font-mono font-bold bg-amber-100 px-1.5 py-0.5 rounded text-slate-900">@Daniel1995</span> | Senha: <span className="font-mono font-bold bg-amber-100 px-1.5 py-0.5 rounded text-slate-900">1010</span>
            </p>
          </div>
        </div>
        <div className="text-xs text-amber-800/80">
          Você pode alterar este usuário ou cadastrar novos administradores abaixo.
        </div>
      </div>

      {/* Status Feedback Message */}
      {statusMessage && (
        <div 
          className={`p-4 rounded-xl text-xs sm:text-sm font-semibold flex items-center gap-3 animate-fadeIn ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
              : 'bg-red-50 text-red-800 border border-red-200'
          }`}
        >
          {statusMessage.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          ) : (
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Create / Edit Form Drawer/Panel */}
      {isFormOpen && (
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-lg p-6 sm:p-8 animate-fadeIn">
          <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-red-50 text-red-600">
                {editingUserId ? <Edit3 className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-bold text-slate-900">
                  {editingUserId ? 'Alterar Usuário de Acesso' : 'Cadastrar Novo Usuário'}
                </h3>
                <p className="text-xs text-slate-500">
                  {editingUserId ? 'Altere o nome de login ou defina uma nova senha' : 'Crie um novo acesso administrativo para o portal'}
                </p>
              </div>
            </div>

            <button
              onClick={resetForm}
              className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Fechar formulário"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSaveUser} className="space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* Username Input */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Usuário (Login) *
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="Ex: @Daniel1995"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-red-600 focus:bg-white text-slate-900 font-medium"
                  />
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                </div>
                <span className="text-[11px] text-slate-500 mt-1 block">Nome usado para entrar no painel administrativo</span>
              </div>

              {/* Display Name */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Nome Completo ou Apelido
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ex: Daniel"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-red-600 focus:bg-white text-slate-900"
                  />
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                </div>
                <span className="text-[11px] text-slate-500 mt-1 block">Identificação exibida no painel</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {/* Role Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Nível de Acesso
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as 'admin' | 'editor')}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-red-600 focus:bg-white text-slate-900 cursor-pointer font-medium"
                >
                  <option value="admin">Administrador Geral (Acesso total)</option>
                  <option value="editor">Editor (Redação de matérias)</option>
                </select>
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Senha de Acesso *
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Digite a senha"
                    className="w-full pl-10 pr-11 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-red-600 focus:bg-white text-slate-900 font-mono"
                  />
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                    title={showPassword ? 'Ocultar senha' : 'Exibir senha'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>

            {/* Confirm Password */}
            <div className="sm:w-1/2">
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Confirmar Senha *
              </label>
              <div className="relative">
                <input
                  type={showConfirmPassword ? 'text' : 'password'}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repita a senha para confirmar"
                  className="w-full pl-10 pr-11 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-red-600 focus:bg-white text-slate-900 font-mono"
                />
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                  title={showConfirmPassword ? 'Ocultar senha' : 'Exibir senha'}
                >
                  {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={resetForm}
                className="px-4 py-2.5 text-xs sm:text-sm font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs sm:text-sm font-bold shadow-md hover:shadow-lg transition-all flex items-center gap-2 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>{editingUserId ? 'Salvar Alterações' : 'Criar Usuário'}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Users Table / List */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-slate-100 text-slate-700">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900">
                Usuários Cadastrados
              </h3>
              <p className="text-xs text-slate-500">
                Total de {users.length} {users.length === 1 ? 'usuário ativo' : 'usuários ativos'} com acesso ao painel
              </p>
            </div>
          </div>

          {!isFormOpen && (
            <button
              onClick={handleStartCreate}
              className="px-4 py-2 bg-slate-900 hover:bg-red-600 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Usuário</span>
            </button>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200/70 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                <th className="py-3.5 px-6">Usuário (Login)</th>
                <th className="py-3.5 px-6">Nome</th>
                <th className="py-3.5 px-6">Função</th>
                <th className="py-3.5 px-6">Senha</th>
                <th className="py-3.5 px-6 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs sm:text-sm">
              {users.map((u) => {
                const isDefault = u.username.toLowerCase() === 'daniel1995';

                return (
                  <tr key={u.id} className="hover:bg-slate-50/60 transition-colors">
                    <td className="py-4 px-6 font-semibold text-slate-900">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center text-slate-700 font-bold text-xs uppercase">
                          {u.username.substring(0, 2)}
                        </div>
                        <span className="font-mono">{u.username}</span>
                        {isDefault && (
                          <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-bold">
                            Padrão
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-4 px-6 text-slate-700">
                      {u.name || u.username}
                    </td>
                    <td className="py-4 px-6">
                      <span className={`px-2.5 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider ${
                        u.role === 'admin' 
                          ? 'bg-red-50 text-red-700 border border-red-200' 
                          : 'bg-blue-50 text-blue-700 border border-blue-200'
                      }`}>
                        {u.role === 'admin' ? 'Administrador' : 'Editor'}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-slate-500 font-mono text-xs">
                      ••••••••
                    </td>
                    <td className="py-4 px-6 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleStartEdit(u)}
                          className="p-1.5 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                          title="Alterar usuário ou senha"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setUserToDelete(u)}
                          className="p-1.5 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                          title="Excluir usuário"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete User Confirmation Modal */}
      <ConfirmModal
        isOpen={Boolean(userToDelete)}
        title="Excluir Usuário de Acesso"
        message={
          users.length <= 1
            ? `Tem certeza que deseja excluir o usuário "${userToDelete?.username}"? Como este é o único usuário ativo, o usuário padrão de segurança (@Daniel1995 com senha 1010) será redefinido automaticamente para que você nunca perca o acesso.`
            : `Tem certeza que deseja excluir o usuário "${userToDelete?.username}"? Esta pessoa perderá o acesso ao painel administrativo imediatamente.`
        }
        confirmText="Sim, Excluir Usuário"
        cancelText="Cancelar"
        variant="danger"
        icon="trash"
        onConfirm={handleConfirmDelete}
        onCancel={() => setUserToDelete(null)}
      />

      {/* Reset Default Users Confirmation Modal */}
      <ConfirmModal
        isOpen={showResetConfirm}
        title="Restaurar Usuário Padrão?"
        message="Esta operação restaurará o acesso padrão com Usuário: @Daniel1995 e Senha: 1010. Deseja continuar?"
        confirmText="Sim, Restaurar"
        cancelText="Voltar"
        variant="warning"
        icon="warning"
        onConfirm={handleRestoreDefaults}
        onCancel={() => setShowResetConfirm(false)}
      />
    </div>
  );
};
