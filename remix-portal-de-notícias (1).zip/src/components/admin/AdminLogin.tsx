import React, { useState } from 'react';
import { Lock, User, Key, ArrowLeft, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { storageService } from '../../services/storageService';
import { AdminUser } from '../../types';

interface AdminLoginProps {
  onLoginSuccess: (user?: AdminUser) => void;
  onCancel: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ onLoginSuccess, onCancel }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    setTimeout(() => {
      // Check against stored admin users in storageService
      const result = storageService.verifyAdminUser(username, password);

      if (result.success && result.user) {
        localStorage.setItem('portal_admin_session', JSON.stringify({
          logged: true,
          username: result.user.username,
          userId: result.user.id,
          role: result.user.role || 'admin',
          time: new Date().toISOString()
        }));
        onLoginSuccess(result.user);
      } else {
        setError(result.message || 'Usuário ou senha incorretos. Verifique os dados.');
        setIsLoading(false);
      }
    }, 350);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/80 z-50 flex items-center justify-center p-4 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
        {/* Top Header */}
        <div className="bg-slate-900 text-white p-6 relative">
          <button
            onClick={onCancel}
            className="absolute top-5 left-5 p-1.5 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
            title="Voltar ao portal"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          
          <div className="flex flex-col items-center text-center mt-2">
            <div className="w-12 h-12 rounded-xl bg-red-600 flex items-center justify-center text-white shadow-lg mb-3">
              <Lock className="w-6 h-6" />
            </div>
            <h2 className="text-xl font-bold tracking-tight">Painel Administrativo</h2>
            <p className="text-xs text-slate-400 mt-1">Acesso restrito para editores e gestão do portal</p>
          </div>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700 flex items-center gap-2 animate-fadeIn">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Usuário de Acesso
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Ex: @Daniel1995"
                autoComplete="username"
                className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-red-600 focus:bg-white text-slate-900 placeholder:text-slate-400 transition-colors font-medium"
              />
              <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Senha
            </label>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Ex: 1010"
                autoComplete="current-password"
                className="w-full pl-10 pr-11 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-hidden focus:ring-2 focus:ring-red-600 focus:bg-white text-slate-900 placeholder:text-slate-400 transition-colors font-medium"
              />
              <Key className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                title={showPassword ? 'Ocultar senha' : 'Exibir senha'}
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Quick Info & Default Credentials Auto-Fill */}
          <div className="p-3 bg-slate-50 border border-slate-200/90 rounded-xl flex items-center justify-between gap-3 text-xs">
            <div className="min-w-0">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block">
                Login Padrão de Segurança
              </span>
              <div className="flex items-center gap-1.5 mt-0.5 text-xs">
                <span className="font-mono font-bold text-slate-800">@Daniel1995</span>
                <span className="text-slate-400">•</span>
                <span className="font-mono text-slate-600">Senha: 1010</span>
              </div>
            </div>
            <button
              type="button"
              onClick={() => {
                setUsername('@Daniel1995');
                setPassword('1010');
                setError('');
              }}
              className="px-2.5 py-1.5 bg-white hover:bg-slate-100 text-red-600 hover:text-red-700 border border-slate-200 rounded-lg text-xs font-bold transition-all shrink-0 cursor-pointer shadow-2xs"
              title="Preencher com login padrão"
            >
              Preencher
            </button>
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-sm font-bold shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70"
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>Entrar no Painel</span>
                </>
              )}
            </button>
          </div>

          <div className="text-center pt-2">
            <button
              type="button"
              onClick={onCancel}
              className="text-xs text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
            >
              Cancelar e voltar ao site público
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

