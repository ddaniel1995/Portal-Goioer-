import { Article, Category } from '../types';

/**
 * Remove accents, special characters, and convert text to URL-friendly slug
 * Example: "Prefeitura anuncia novo projeto em Goioerê" -> "prefeitura-anuncia-novo-projeto-em-goioere"
 */
export function slugify(text: string): string {
  if (!text) return '';
  return text
    .toString()
    .toLowerCase()
    .normalize('NFD') // split accented characters into base char + accent
    .replace(/[\u0300-\u036f]/g, '') // remove accent marks
    .replace(/[^a-z0-9]+/g, '-') // replace non-alphanumeric with hyphen
    .replace(/^-+|-+$/g, '') // trim leading/trailing hyphens
    .replace(/-{2,}/g, '-'); // replace multiple consecutive hyphens with single hyphen
}

/**
 * Get canonical URL for an article: /noticias/:categorySlug/:articleSlug
 */
export function getArticleUrl(article: Article, categories?: Category[]): string {
  if (!article) return '/noticias';
  
  let catSlug = '';
  if (categories && article.categoryId) {
    const matched = categories.find(c => c.id === article.categoryId || c.slug === article.categoryId);
    if (matched?.slug) catSlug = matched.slug;
  }
  
  if (!catSlug && article.categoryName) {
    catSlug = slugify(article.categoryName);
  }
  
  if (!catSlug) {
    catSlug = 'geral';
  }

  const artSlug = article.slug || slugify(article.title) || article.id;
  return `/noticias/${catSlug}/${artSlug}`;
}

/**
 * Get canonical URL for a category: /noticias/:categorySlug
 */
export function getCategoryUrl(categorySlugOrId: string, categories?: Category[]): string {
  if (!categorySlugOrId || categorySlugOrId === 'all') return '/noticias';
  if (categorySlugOrId === 'cat-ultimas' || categorySlugOrId === 'ultimas') return '/noticias/ultimas';

  if (categories) {
    const matched = categories.find(c => c.id === categorySlugOrId || c.slug === categorySlugOrId);
    if (matched?.slug) return `/noticias/${matched.slug}`;
  }

  return `/noticias/${slugify(categorySlugOrId)}`;
}

/**
 * Get canonical URL for a business store minisite
 */
export function getStoreUrl(storeSlug: string): string {
  return `/guia-empresarial/${storeSlug}`;
}

/**
 * Get canonical URL for the business guide
 */
export function getBusinessGuideUrl(category?: string): string {
  if (category && category !== 'all') {
    return `/guia-empresarial?categoria=${encodeURIComponent(category)}`;
  }
  return '/guia-empresarial';
}
