import React, { useState, useEffect } from 'react';
import { Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import { 
  Article, 
  Category, 
  Banner, 
  VisualIdentity, 
  FacebookConfig,
  SitePopup,
  BusinessGuideConfig,
  BusinessStore,
  BusinessProductService
} from './types';
import { storageService } from './services/storageService';
import { faviconService } from './services/faviconService';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { SitePopupModal } from './components/SitePopupModal';
import { AdminPanel } from './components/admin/AdminPanel';
import { AdminLogin } from './components/admin/AdminLogin';

import { HomeView } from './views/HomeView';
import { CategoryPageView } from './views/CategoryPageView';
import { ArticlePageView } from './views/ArticlePageView';
import { SearchPageView } from './views/SearchPageView';
import { BusinessGuidePageView } from './views/BusinessGuidePageView';
import { BusinessStorePageView } from './views/BusinessStorePageView';
import { getCategoryUrl, getStoreUrl } from './utils/navigation';

function ScrollToTop() {
  const { pathname } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [pathname]);

  return null;
}

export default function App() {
  const navigate = useNavigate();
  const location = useLocation();

  // Application Data States (synced with storageService)
  const [articles, setArticles] = useState<Article[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [banners, setBanners] = useState<Banner[]>([]);
  const [identity, setIdentity] = useState<VisualIdentity>(storageService.getVisualIdentity());
  const [facebookConfig, setFacebookConfig] = useState<FacebookConfig>(storageService.getFacebookConfig());
  const [sitePopup, setSitePopup] = useState<SitePopup>(storageService.getSitePopup());

  // Business Guide Data States
  const [businessConfig, setBusinessConfig] = useState<BusinessGuideConfig>(storageService.getBusinessGuideConfig());
  const [businessStores, setBusinessStores] = useState<BusinessStore[]>([]);
  const [businessProducts, setBusinessProducts] = useState<BusinessProductService[]>([]);

  // Admin Access & Authentication
  const isAdminRoute = location.pathname === '/adm' || location.pathname === '/admin';
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState(false);

  // Initialize and load data
  const loadPortalData = () => {
    setArticles(storageService.getArticles());
    setCategories(storageService.getCategories());
    setBanners(storageService.getBanners());
    const currentIdentity = storageService.getVisualIdentity();
    setIdentity(currentIdentity);
    faviconService.applyFavicon(currentIdentity.faviconUrl);
    setFacebookConfig(storageService.getFacebookConfig());
    setSitePopup(storageService.getSitePopup());
    setBusinessConfig(storageService.getBusinessGuideConfig());
    setBusinessStores(storageService.getBusinessStores());
    setBusinessProducts(storageService.getBusinessProducts());
  };

  useEffect(() => {
    loadPortalData();

    const handlePortalUpdate = () => {
      loadPortalData();
    };
    window.addEventListener('portal_data_updated', handlePortalUpdate);

    // Check saved admin session
    const savedSession = localStorage.getItem('portal_admin_session');
    if (savedSession) {
      try {
        const parsed = JSON.parse(savedSession);
        if (parsed?.logged) {
          setIsAdminAuthenticated(true);
        }
      } catch (e) {
        console.error(e);
      }
    }

    return () => {
      window.removeEventListener('portal_data_updated', handlePortalUpdate);
    };
  }, []);

  const handleBannerClick = (banner: Banner) => {
    storageService.incrementBannerClicks(banner.id);
    if (banner.targetUrl) {
      window.open(banner.targetUrl, '_blank', 'noopener,noreferrer');
    }
  };

  // Admin Access Handling
  const handleOpenAdminFromFooter = () => {
    navigate('/adm');
  };

  const handleLoginSuccess = () => {
    setIsAdminAuthenticated(true);
    navigate('/adm');
  };

  const handleLogout = () => {
    setIsAdminAuthenticated(false);
    localStorage.removeItem('portal_admin_session');
    storageService.setCurrentAdminUser(null);
    navigate('/');
  };

  // If current URL is /adm or /admin, render Admin Screen or Login Screen
  if (isAdminRoute) {
    if (isAdminAuthenticated) {
      return (
        <AdminPanel
          articles={articles}
          categories={categories}
          banners={banners}
          identity={identity}
          facebookConfig={facebookConfig}
          onRefreshData={loadPortalData}
          onCloseAdmin={() => navigate('/')}
          onLogout={handleLogout}
          onOpenStorePreview={(slug) => {
            navigate(getStoreUrl(slug));
          }}
        />
      );
    } else {
      return (
        <AdminLogin
          onLoginSuccess={handleLoginSuccess}
          onCancel={() => navigate('/')}
        />
      );
    }
  }

  return (
    <div 
      className="min-h-screen flex flex-col text-slate-900 selection:bg-red-600 selection:text-white transition-colors"
      style={{ backgroundColor: identity.colors?.pageBg || '#f8fafc' }}
    >
      <ScrollToTop />

      {/* Top Header */}
      <Header
        identity={identity}
        categories={categories}
        businessGuideConfig={businessConfig}
        onOpenBusinessGuide={() => navigate('/guia-empresarial')}
        onSelectCategory={(categoryId) => navigate(getCategoryUrl(categoryId, categories))}
        onSearch={(query) => navigate(`/busca?q=${encodeURIComponent(query)}`)}
        onGoHome={() => navigate('/')}
      />

      {/* Main Public Body with URL-based Routes */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Routes>
          {/* 1. Página Inicial: https://portalgoioereeassim.com.br/ */}
          <Route
            path="/"
            element={
              <HomeView
                articles={articles}
                categories={categories}
                banners={banners}
                businessConfig={businessConfig}
                businessStores={businessStores}
                onBannerClick={handleBannerClick}
              />
            }
          />

          {/* 2. Página de Notícias Geral: https://portalgoioereeassim.com.br/noticias */}
          <Route
            path="/noticias"
            element={
              <CategoryPageView
                categories={categories}
                articles={articles}
                banners={banners}
                onBannerClick={handleBannerClick}
              />
            }
          />

          {/* 3. Categorias: https://portalgoioereeassim.com.br/noticias/:category */}
          <Route
            path="/noticias/:category"
            element={
              <CategoryPageView
                categories={categories}
                articles={articles}
                banners={banners}
                onBannerClick={handleBannerClick}
              />
            }
          />

          {/* Aliases para rotas de categorias */}
          <Route
            path="/categoria/:category"
            element={
              <CategoryPageView
                categories={categories}
                articles={articles}
                banners={banners}
                onBannerClick={handleBannerClick}
              />
            }
          />

          {/* 4. Matérias / Artigos por Slug: https://portalgoioereeassim.com.br/noticias/:category/:articleSlug */}
          <Route
            path="/noticias/:category/:articleSlug"
            element={
              <ArticlePageView
                articles={articles}
                categories={categories}
                banners={banners}
              />
            }
          />

          {/* Aliases para matérias diretas */}
          <Route
            path="/noticia/:articleSlug"
            element={
              <ArticlePageView
                articles={articles}
                categories={categories}
                banners={banners}
              />
            }
          />

          {/* 5. Busca: /busca?q=... */}
          <Route
            path="/busca"
            element={
              <SearchPageView
                articles={articles}
                categories={categories}
              />
            }
          />
          <Route
            path="/pesquisa"
            element={
              <SearchPageView
                articles={articles}
                categories={categories}
              />
            }
          />

          {/* 6. Guia Empresarial: /guia-empresarial */}
          <Route
            path="/guia-empresarial"
            element={
              <BusinessGuidePageView
                config={businessConfig}
                stores={businessStores}
              />
            }
          />

          {/* 7. Minisite da Loja no Guia Empresarial: /guia-empresarial/:storeSlug */}
          <Route
            path="/guia-empresarial/:storeSlug"
            element={
              <BusinessStorePageView
                stores={businessStores}
                products={businessProducts}
              />
            }
          />

          {/* 8. Fallback / Rota 404 redireciona suavemente para Home */}
          <Route
            path="*"
            element={
              <HomeView
                articles={articles}
                categories={categories}
                banners={banners}
                businessConfig={businessConfig}
                businessStores={businessStores}
                onBannerClick={handleBannerClick}
              />
            }
          />
        </Routes>
      </main>

      {/* Footer */}
      <Footer
        identity={identity}
        categories={categories}
        businessGuideConfig={businessConfig}
        onOpenBusinessGuide={() => navigate('/guia-empresarial')}
        onSelectCategory={(categoryId) => navigate(getCategoryUrl(categoryId, categories))}
        onGoHome={() => navigate('/')}
        onOpenAdmin={handleOpenAdminFromFooter}
      />

      {/* Global Site PopUp with Attached Image */}
      <SitePopupModal
        popup={sitePopup}
        isHomePage={location.pathname === '/'}
      />
    </div>
  );
}
