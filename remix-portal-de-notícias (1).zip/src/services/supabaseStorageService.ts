import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Configuration from environment variables
const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL || '').trim();
const supabaseAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY || '').trim();

let clientInstance: SupabaseClient | null = null;

/**
 * Checks if Supabase credentials are configured in the environment
 */
export function isSupabaseConfigured(): boolean {
  return Boolean(supabaseUrl && supabaseAnonKey);
}

/**
 * Returns the Supabase client instance or null if not configured
 */
export function getSupabaseClient(): SupabaseClient | null {
  if (!isSupabaseConfigured()) {
    return null;
  }
  if (!clientInstance) {
    try {
      clientInstance = createClient(supabaseUrl, supabaseAnonKey);
    } catch (err) {
      console.warn('Failed to initialize Supabase client:', err);
      return null;
    }
  }
  return clientInstance;
}

export const supabase = isSupabaseConfigured() ? getSupabaseClient() : null;

export const supabaseStorageService = {
  isConfigured: isSupabaseConfigured,
  getClient: getSupabaseClient,

  /**
   * Upload an image/file to a Supabase storage bucket
   */
  async uploadImage(file: File, bucket = 'images', customPath?: string): Promise<{ url: string | null; error: Error | null }> {
    const client = getSupabaseClient();
    if (!client) {
      return { url: null, error: new Error('Supabase não está configurado. Defina VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY.') };
    }

    try {
      const extension = file.name.split('.').pop() || 'png';
      const cleanFileName = file.name.replace(/[^a-zA-Z0-9.-]/g, '_');
      const filePath = customPath || `uploads/${Date.now()}_${cleanFileName}`;

      const { data, error } = await client.storage.from(bucket).upload(filePath, file, {
        cacheControl: '3600',
        upsert: true,
      });

      if (error) {
        return { url: null, error };
      }

      const { data: publicUrlData } = client.storage.from(bucket).getPublicUrl(data.path);
      return { url: publicUrlData.publicUrl, error: null };
    } catch (err) {
      return { url: null, error: err instanceof Error ? err : new Error(String(err)) };
    }
  },

  /**
   * Delete a file from a Supabase storage bucket
   */
  async deleteImage(path: string, bucket = 'images'): Promise<{ success: boolean; error: Error | null }> {
    const client = getSupabaseClient();
    if (!client) {
      return { success: false, error: new Error('Supabase não está configurado.') };
    }

    try {
      const { error } = await client.storage.from(bucket).remove([path]);
      if (error) {
        return { success: false, error };
      }
      return { success: true, error: null };
    } catch (err) {
      return { success: false, error: err instanceof Error ? err : new Error(String(err)) };
    }
  },

  /**
   * Get public URL for a given path
   */
  getPublicUrl(path: string, bucket = 'images'): string | null {
    const client = getSupabaseClient();
    if (!client) return null;
    const { data } = client.storage.from(bucket).getPublicUrl(path);
    return data.publicUrl;
  }
};
