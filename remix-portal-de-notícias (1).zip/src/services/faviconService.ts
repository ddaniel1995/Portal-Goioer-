/**
 * Favicon Management Service
 * Handles live browser favicon injection, preset generators,
 * data URL conversions, and export helpers for Vercel and GitHub deployments.
 */

export interface FaviconPreset {
  id: string;
  name: string;
  description: string;
  category: 'padrao' | 'noticias' | 'minimalista' | 'urgente';
  svgDataUri: string;
}

// Default modern SVG favicon
export const DEFAULT_FAVICON_SVG = `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64' fill='none'%3E%3Crect width='64' height='64' rx='16' fill='%23dc2626'/%3E%3Cpath d='M18 16H34C41.732 16 48 22.268 48 30C48 37.732 41.732 44 34 44H26V48H18V16Z' fill='white'/%3E%3Cpath d='M26 24H34C37.3137 24 40 26.6863 40 30C40 33.3137 37.3137 36 34 36H26V24Z' fill='%23dc2626'/%3E%3Ccircle cx='48' cy='16' r='6' fill='%23facc15'/%3E%3C/svg%3E`;

// Pre-designed high-contrast favicons for news portals
export const FAVICON_PRESETS: FaviconPreset[] = [
  {
    id: 'preset-portal-red',
    name: 'Portal Clássico (Vermelho)',
    description: 'Ícone emblemático com letra P estilizada e ponto de destaque âmbar.',
    category: 'padrao',
    svgDataUri: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64' fill='none'%3E%3Crect width='64' height='64' rx='16' fill='%23dc2626'/%3E%3Cpath d='M18 16H34C41.732 16 48 22.268 48 30C48 37.732 41.732 44 34 44H26V48H18V16Z' fill='white'/%3E%3Cpath d='M26 24H34C37.3137 24 40 26.6863 40 30C40 33.3137 37.3137 36 34 36H26V24Z' fill='%23dc2626'/%3E%3Ccircle cx='48' cy='16' r='6' fill='%23facc15'/%3E%3C/svg%3E`
  },
  {
    id: 'preset-news-live',
    name: 'Jornal & Notícias (Editorial)',
    description: 'Símbolo clássico de jornal impresso em fundo azul escuro corporativo.',
    category: 'noticias',
    svgDataUri: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64' fill='none'%3E%3Crect width='64' height='64' rx='16' fill='%230f172a'/%3E%3Crect x='14' y='14' width='36' height='36' rx='4' fill='%23f8fafc'/%3E%3Crect x='18' y='20' width='16' height='12' rx='2' fill='%23dc2626'/%3E%3Crect x='38' y='20' width='8' height='3' rx='1' fill='%23334155'/%3E%3Crect x='38' y='25' width='8' height='3' rx='1' fill='%23334155'/%3E%3Crect x='38' y='29' width='8' height='3' rx='1' fill='%23334155'/%3E%3Crect x='18' y='36' width='28' height='3' rx='1' fill='%2364748b'/%3E%3Crect x='18' y='41' width='22' height='3' rx='1' fill='%2394a3b8'/%3E%3C/svg%3E`
  },
  {
    id: 'preset-global-blue',
    name: 'Globo Internacional (Azul)',
    description: 'Globo conectado ideal para portais com foco em mundo, tecnologia e economia.',
    category: 'noticias',
    svgDataUri: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64' fill='none'%3E%3Crect width='64' height='64' rx='16' fill='%231d4ed8'/%3E%3Ccircle cx='32' cy='32' r='20' stroke='white' stroke-width='4'/%3E%3Cellipse cx='32' cy='32' rx='9' ry='20' stroke='white' stroke-width='3.5'/%3E%3Cline x1='12' y1='32' x2='52' y2='32' stroke='white' stroke-width='3.5'/%3E%3Cline x1='16' y1='23' x2='48' y2='23' stroke='white' stroke-width='2.5'/%3E%3Cline x1='16' y1='41' x2='48' y2='41' stroke='white' stroke-width='2.5'/%3E%3C/svg%3E`
  },
  {
    id: 'preset-broadcast-antenna',
    name: 'Transmissão Ao Vivo (Ondas)',
    description: 'Torre de sinal e transmissão ao vivo com ondas de rádio e TV.',
    category: 'urgente',
    svgDataUri: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64' fill='none'%3E%3Crect width='64' height='64' rx='16' fill='%23b91c1c'/%3E%3Ccircle cx='32' cy='32' r='5' fill='%23fef08a'/%3E%3Cpath d='M23 23C27.9706 18.0294 36.0294 18.0294 41 23' stroke='white' stroke-width='4' stroke-linecap='round'/%3E%3Cpath d='M16 16C24.8366 7.16344 39.1634 7.16344 48 16' stroke='white' stroke-width='4' stroke-linecap='round'/%3E%3Cpath d='M28 44L32 37L36 44' stroke='white' stroke-width='4' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cline x1='32' y1='44' x2='32' y2='52' stroke='white' stroke-width='4' stroke-linecap='round'/%3E%3C/svg%3E`
  },
  {
    id: 'preset-minimal-black',
    name: 'Monograma Minimal (Grafite)',
    description: 'Estilo clean e sofisticado para portais independentes e revistas digitais.',
    category: 'minimalista',
    svgDataUri: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64' fill='none'%3E%3Crect width='64' height='64' rx='14' fill='%2318181b'/%3E%3Cpath d='M22 16H34C40.6274 16 46 21.3726 46 28C46 34.6274 40.6274 40 34 40H28V48H22V16Z' fill='%23fafafa'/%3E%3Crect x='28' y='22' width='8' height='12' rx='2' fill='%2318181b'/%3E%3Ccircle cx='44' cy='44' r='4' fill='%23f59e0b'/%3E%3C/svg%3E`
  },
  {
    id: 'preset-emerald-growth',
    name: 'Esmeralda & Negócios (Verde)',
    description: 'Tom verde de credibilidade para canais de economia, sustentabilidade e agro.',
    category: 'noticias',
    svgDataUri: `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64' fill='none'%3E%3Crect width='64' height='64' rx='16' fill='%23047857'/%3E%3Cpath d='M16 44L28 32L36 40L48 24' stroke='white' stroke-width='5' stroke-linecap='round' stroke-linejoin='round'/%3E%3Cpath d='M38 24H48V34' stroke='white' stroke-width='5' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E`
  }
];

export const faviconService = {
  /**
   * Applies the favicon to the current HTML document immediately.
   * Updates all <link rel="icon"> and <link rel="apple-touch-icon"> elements.
   */
  applyFavicon(faviconUrl?: string): void {
    if (typeof document === 'undefined') return;

    const url = (faviconUrl && faviconUrl.trim()) ? faviconUrl.trim() : DEFAULT_FAVICON_SVG;

    // 1. Icon element
    let iconLink = document.querySelector<HTMLLinkElement>("link[rel='icon']");
    if (!iconLink) {
      iconLink = document.createElement('link');
      iconLink.rel = 'icon';
      document.head.appendChild(iconLink);
    }
    iconLink.href = url;

    // Detect MIME type
    if (url.startsWith('data:image/svg+xml') || url.endsWith('.svg')) {
      iconLink.type = 'image/svg+xml';
    } else if (url.endsWith('.png') || url.startsWith('data:image/png')) {
      iconLink.type = 'image/png';
    } else if (url.endsWith('.ico') || url.startsWith('data:image/x-icon')) {
      iconLink.type = 'image/x-icon';
    } else {
      iconLink.type = 'image/png';
    }

    // 2. Shortcut icon for legacy browsers
    let shortcutLink = document.querySelector<HTMLLinkElement>("link[rel='shortcut icon']");
    if (!shortcutLink) {
      shortcutLink = document.createElement('link');
      shortcutLink.rel = 'shortcut icon';
      document.head.appendChild(shortcutLink);
    }
    shortcutLink.href = url;

    // 3. Apple Touch Icon for iOS Safari & Home Screen
    let appleLink = document.querySelector<HTMLLinkElement>("link[rel='apple-touch-icon']");
    if (!appleLink) {
      appleLink = document.createElement('link');
      appleLink.rel = 'apple-touch-icon';
      document.head.appendChild(appleLink);
    }
    appleLink.href = url;

    // Dispatch global event for UI components listening
    window.dispatchEvent(new CustomEvent('portal_favicon_updated', { detail: { url } }));
  },

  /**
   * Generates a custom SVG Favicon data URL from a letter/initial and background color.
   */
  generateLetterFavicon(letter: string, bgColor: string = '#dc2626', textColor: string = '#ffffff'): string {
    const cleanLetter = (letter.trim()[0] || 'P').toUpperCase();
    const safeBg = encodeURIComponent(bgColor);
    const safeText = encodeURIComponent(textColor);

    const svg = `<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64' fill='none'>` +
      `<rect width='64' height='64' rx='16' fill='${safeBg}'/>` +
      `<text x='50%' y='55%' text-anchor='middle' dominant-baseline='middle' font-family='system-ui, -apple-system, sans-serif' font-weight='900' font-size='38' fill='${safeText}'>${cleanLetter}</text>` +
      `<circle cx='50' cy='14' r='5' fill='%23facc15'/>` +
      `</svg>`;

    return `data:image/svg+xml,${svg}`;
  },

  /**
   * Generates the HTML code snippet for inclusion in index.html (useful for GitHub / Vercel deploys)
   */
  generateHtmlSnippet(faviconUrl?: string): string {
    const url = faviconUrl || '/favicon.svg';
    const isSvg = url.includes('.svg') || url.startsWith('data:image/svg+xml');
    const type = isSvg ? 'image/svg+xml' : 'image/png';

    return `<!-- Favicon configurado para Vercel & GitHub -->\n` +
      `<link rel="icon" type="${type}" href="${url}" />\n` +
      `<link rel="shortcut icon" href="${url}" />\n` +
      `<link rel="apple-touch-icon" href="${url}" />`;
  },

  /**
   * Downloads the favicon file directly to the user's computer.
   * This file can be placed into the repository's /public/ folder for Vercel & GitHub.
   */
  async downloadFavicon(faviconUrl: string, fileName = 'favicon.png'): Promise<void> {
    try {
      if (faviconUrl.startsWith('data:image/svg+xml')) {
        // Convert SVG to PNG canvas for maximum compatibility with .ico / .png
        const img = new Image();
        img.crossOrigin = 'anonymous';

        await new Promise((resolve, reject) => {
          img.onload = resolve;
          img.onerror = reject;
          img.src = faviconUrl;
        });

        const canvas = document.createElement('canvas');
        canvas.width = 64;
        canvas.height = 64;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, 64, 64);
          canvas.toBlob((blob) => {
            if (blob) {
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = fileName;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
            }
          }, 'image/png');
        }
      } else if (faviconUrl.startsWith('data:')) {
        // Direct data URL
        const a = document.createElement('a');
        a.href = faviconUrl;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      } else {
        // External URL -> fetch as blob
        const response = await fetch(faviconUrl);
        const blob = await response.blob();
        const blobUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = blobUrl;
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(blobUrl);
      }
    } catch (e) {
      console.error('Error downloading favicon file', e);
      // Fallback: open link in new tab or trigger direct download
      const a = document.createElement('a');
      a.href = faviconUrl;
      a.target = '_blank';
      a.download = fileName;
      a.click();
    }
  }
};
