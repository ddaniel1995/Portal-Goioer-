import { Article, Category, Banner, VisualIdentity, FacebookConfig, FacebookLog, BannerPosition, SitePopup, BusinessGuideConfig, BusinessStore, BusinessProductService, AdminCredentials, AdminUser } from '../types';
import { initialArticles, initialCategories, initialBanners, initialVisualIdentity, initialFacebookConfig, initialSitePopup } from '../data/initialData';
import { initialBusinessGuideConfig, initialBusinessStores, initialBusinessProducts } from '../data/initialBusinesses';
import { applyThemeColors, applyThemeTypography, DEFAULT_COLORS, DEFAULT_TYPOGRAPHY } from './themeService';
import { slugify } from '../utils/navigation';

export { slugify };

const STORAGE_KEYS = {
  ARTICLES: 'portal_news_articles_v1',
  CATEGORIES: 'portal_news_categories_v1',
  BANNERS: 'portal_news_banners_v1',
  IDENTITY: 'portal_news_identity_v1',
  FB_CONFIG: 'portal_news_fb_config_v1',
  FB_LOGS: 'portal_news_fb_logs_v1',
  ADMIN_AUTH: 'portal_news_admin_auth_v1',
  ADMIN_USERS: 'portal_news_admin_users_v2',
  CURRENT_USER: 'portal_news_current_user_v2',
  POPUP: 'portal_news_site_popup_v1',
  BUSINESS_CONFIG: 'portal_news_business_config_v1',
  BUSINESS_STORES: 'portal_news_business_stores_v1',
  BUSINESS_PRODUCTS: 'portal_news_business_products_v1',
};

// YouTube ID Extractor helper
export function extractYoutubeId(url?: string): string | null {
  if (!url) return null;
  const regExp = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/|youtube\.com\/shorts\/)([^"&?\/\s]{11})/i;
  const match = url.match(regExp);
  return match && match[1] ? match[1] : null;
}

// Storage helpers
export const storageService = {
  // Articles
  getArticles(): Article[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ARTICLES);
      if (data) {
        let parsed: Article[] = JSON.parse(data);
        // Ensure initial podcast episodes exist if none are found in current storage
        const hasPodcastArticles = parsed.some(a => a.categoryId === 'cat-podcast');
        if (!hasPodcastArticles) {
          const podcastArticles = initialArticles.filter(a => a.categoryId === 'cat-podcast');
          if (podcastArticles.length > 0) {
            parsed = [...parsed, ...podcastArticles];
          }
        }
        // Normalize slugs
        return parsed.map(a => ({
          ...a,
          slug: slugify(a.slug || a.title),
        }));
      }
    } catch (e) {
      console.error('Failed to load articles from storage', e);
    }
    const normalized = initialArticles.map(a => ({
      ...a,
      slug: slugify(a.slug || a.title),
    }));
    this.saveArticles(normalized);
    return normalized;
  },

  saveArticles(articles: Article[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ARTICLES, JSON.stringify(articles));
      window.dispatchEvent(new Event('portal_data_updated'));
    } catch (e) {
      console.error('Failed to save articles to storage', e);
    }
  },

  getArticleById(id: string): Article | undefined {
    return this.getArticles().find(a => a.id === id);
  },

  getArticleBySlug(slug: string): Article | undefined {
    const cleanSlug = slugify(slug);
    return this.getArticles().find(a => a.slug === cleanSlug || a.id === slug);
  },

  saveArticle(article: Partial<Article> & { title: string; categoryId: string }): Article {
    const articles = this.getArticles();
    const categories = this.getCategories();
    const category = categories.find(c => c.id === article.categoryId);
    const categoryName = category ? category.name : 'Geral';
    const cleanSlug = slugify(article.slug || article.title);

    let savedArticle: Article;

    if (article.id) {
      const index = articles.findIndex(a => a.id === article.id);
      if (index !== -1) {
        savedArticle = {
          ...articles[index],
          ...article,
          categoryName,
          slug: cleanSlug,
        } as Article;
        articles[index] = savedArticle;
      } else {
        savedArticle = {
          ...article,
          id: article.id,
          slug: cleanSlug,
          categoryName,
          views: article.views || 0,
          additionalImages: article.additionalImages || [],
          publishedAt: article.publishedAt || new Date().toISOString(),
          status: article.status || 'published',
          facebookAutoPublish: article.facebookAutoPublish ?? false,
          facebookPublished: article.facebookPublished ?? false,
        } as Article;
        articles.unshift(savedArticle);
      }
    } else {
      savedArticle = {
        id: 'art-' + Date.now(),
        title: article.title,
        slug: slugify(article.title),
        subtitle: article.subtitle || '',
        content: article.content || '',
        categoryId: article.categoryId,
        categoryName,
        featuredImage: article.featuredImage || 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?q=80&w=1200&auto=format&fit=crop',
        imageCaption: article.imageCaption || '',
        additionalImages: article.additionalImages || [],
        publishedAt: article.publishedAt || new Date().toISOString(),
        author: article.author || 'Redação',
        authorRole: article.authorRole || 'Redator',
        authorAvatar: article.authorAvatar || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?q=80&w=200&auto=format&fit=crop',
        youtubeUrl: article.youtubeUrl || '',
        status: article.status || 'published',
        views: 0,
        isHighlight: article.isHighlight ?? false,
        facebookAutoPublish: article.facebookAutoPublish ?? false,
        facebookPublished: false,
      };
      articles.unshift(savedArticle);
    }

    this.saveArticles(articles);
    return savedArticle;
  },

  deleteArticle(id: string): void {
    const articles = this.getArticles().filter(a => a.id !== id);
    this.saveArticles(articles);
  },

  incrementArticleViews(id: string): void {
    const articles = this.getArticles();
    const article = articles.find(a => a.id === id);
    if (article) {
      article.views = (article.views || 0) + 1;
      this.saveArticles(articles);
    }
  },

  // Categories
  getCategories(): Category[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CATEGORIES);
      if (data) {
        let parsed: Category[] = JSON.parse(data);
        const hasPodcast = parsed.some(c => c.slug === 'podcast' || c.id === 'cat-podcast');
        if (!hasPodcast) {
          const podcastCat: Category = {
            id: 'cat-podcast',
            name: 'Podcast',
            slug: 'podcast',
            order: parsed.length + 1,
            color: '#8b5cf6',
            description: 'Galeria de vídeos e episódios com links diretos do YouTube',
            showOnHome: true,
          };
          parsed.push(podcastCat);
        }
        return parsed.map(c => ({
          ...c,
          slug: slugify(c.slug || c.name),
        }));
      }
    } catch (e) {
      console.error('Failed to load categories', e);
    }
    const normalized = initialCategories.map(c => ({
      ...c,
      slug: slugify(c.slug || c.name),
    }));
    this.saveCategories(normalized);
    return normalized;
  },

  saveCategories(categories: Category[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.CATEGORIES, JSON.stringify(categories));
      window.dispatchEvent(new Event('portal_data_updated'));
    } catch (e) {
      console.error('Failed to save categories', e);
    }
  },

  saveCategory(category: Partial<Category> & { name: string }): Category {
    const categories = this.getCategories();
    let saved: Category;
    const cleanSlug = slugify(category.slug || category.name);

    if (category.id) {
      const idx = categories.findIndex(c => c.id === category.id);
      if (idx !== -1) {
        saved = { ...categories[idx], ...category, slug: cleanSlug };
        categories[idx] = saved;
      } else {
        saved = {
          id: category.id,
          name: category.name,
          slug: cleanSlug,
          order: category.order || categories.length + 1,
          color: category.color || '#2563eb',
          description: category.description || '',
          showOnHome: category.showOnHome ?? true,
          hideInMenu: category.hideInMenu ?? false,
        };
        categories.push(saved);
      }
    } else {
      saved = {
        id: 'cat-' + Date.now(),
        name: category.name,
        slug: cleanSlug,
        order: category.order || categories.length + 1,
        color: category.color || '#2563eb',
        description: category.description || '',
        showOnHome: category.showOnHome ?? true,
        hideInMenu: category.hideInMenu ?? false,
      };
      categories.push(saved);
    }

    this.saveCategories(categories.sort((a, b) => a.order - b.order));
    return saved;
  },

  deleteCategory(id: string): { success: boolean; reassignedCount: number } {
    const allCategories = this.getCategories();
    let remainingCategories = allCategories.filter(c => c.id !== id);

    // If deleting the last category, create a fallback 'Geral' category
    let fallbackCategory = remainingCategories[0];
    if (!fallbackCategory) {
      fallbackCategory = {
        id: 'cat-geral-default',
        name: 'Geral',
        slug: 'geral',
        order: 1,
        color: '#2563eb',
        description: 'Notícias gerais',
        showOnHome: true,
        hideInMenu: false,
      };
      remainingCategories = [fallbackCategory];
    }

    this.saveCategories(remainingCategories);

    // Reassign any articles that used this category so they are preserved
    const articles = this.getArticles();
    let reassignedCount = 0;
    const updatedArticles = articles.map(art => {
      if (art.categoryId === id) {
        reassignedCount++;
        return {
          ...art,
          categoryId: fallbackCategory.id,
          categoryName: fallbackCategory.name,
        };
      }
      return art;
    });

    if (reassignedCount > 0) {
      this.saveArticles(updatedArticles);
    }

    return { success: true, reassignedCount };
  },

  // Banners
  getBanners(): Banner[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.BANNERS);
      if (data) {
        const parsed: Banner[] = JSON.parse(data);
        // Ensure body_slideshow banners exist if none in storage
        const hasBodySlideshow = parsed.some(b => b.position === 'body_slideshow');
        if (!hasBodySlideshow) {
          const bodyBanners = initialBanners.filter(b => b.position === 'body_slideshow');
          if (bodyBanners.length > 0) {
            const merged = [...parsed, ...bodyBanners];
            this.saveBanners(merged);
            return merged;
          }
        }
        return parsed;
      }
    } catch (e) {
      console.error('Failed to load banners', e);
    }
    this.saveBanners(initialBanners);
    return initialBanners;
  },

  saveBanners(banners: Banner[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.BANNERS, JSON.stringify(banners));
      window.dispatchEvent(new Event('portal_data_updated'));
    } catch (e) {
      console.error('Failed to save banners', e);
    }
  },

  saveBanner(banner: Partial<Banner> & { title: string; imageUrl: string; position: BannerPosition }): Banner {
    const banners = this.getBanners();
    let saved: Banner;

    if (banner.id) {
      const idx = banners.findIndex(b => b.id === banner.id);
      if (idx !== -1) {
        saved = { ...banners[idx], ...banner } as Banner;
        banners[idx] = saved;
      } else {
        saved = {
          ...banner,
          id: banner.id,
          order: banner.order || banners.length + 1,
          active: banner.active ?? true,
          clicks: banner.clicks || 0,
        } as Banner;
        banners.push(saved);
      }
    } else {
      saved = {
        id: 'ban-' + Date.now(),
        title: banner.title,
        description: banner.description || '',
        imageUrl: banner.imageUrl,
        targetUrl: banner.targetUrl || '',
        position: banner.position,
        order: banner.order || banners.length + 1,
        active: banner.active ?? true,
        aspectRatio: banner.aspectRatio,
        width: banner.width,
        height: banner.height,
        clicks: 0,
        type: banner.type || (banner.position === 'sidebar' ? 'supporter' : 'commercial'),
        badgeText: banner.badgeText || '',
        showText: banner.showText ?? true,
      };
      banners.push(saved);
    }

    this.saveBanners(banners.sort((a, b) => a.order - b.order));
    return saved;
  },

  deleteBanner(id: string): void {
    const banners = this.getBanners().filter(b => b.id !== id);
    this.saveBanners(banners);
  },

  incrementBannerClicks(id: string): void {
    const banners = this.getBanners();
    const banner = banners.find(b => b.id === id);
    if (banner) {
      banner.clicks = (banner.clicks || 0) + 1;
      this.saveBanners(banners);
    }
  },

  recordBannerClick(id: string): void {
    const banners = this.getBanners();
    const b = banners.find(item => item.id === id);
    if (b) {
      b.clicks = (b.clicks || 0) + 1;
      this.saveBanners(banners);
    }
  },

  // Visual Identity
  getVisualIdentity(): VisualIdentity {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.IDENTITY);
      if (data) {
        const parsed = JSON.parse(data);
        const merged: VisualIdentity = {
          ...initialVisualIdentity,
          ...parsed,
          colors: {
            ...DEFAULT_COLORS,
            ...(initialVisualIdentity.colors || {}),
            ...(parsed.colors || {})
          },
          typography: {
            ...DEFAULT_TYPOGRAPHY,
            ...(initialVisualIdentity.typography || {}),
            ...(parsed.typography || {})
          },
          socialMedia: {
            ...initialVisualIdentity.socialMedia,
            ...(parsed.socialMedia || {})
          }
        };
        applyThemeColors(merged.colors);
        applyThemeTypography(merged.typography);
        return merged;
      }
    } catch (e) {
      console.error('Failed to load visual identity', e);
    }
    this.saveVisualIdentity(initialVisualIdentity);
    applyThemeColors(initialVisualIdentity.colors);
    applyThemeTypography(initialVisualIdentity.typography);
    return initialVisualIdentity;
  },

  saveVisualIdentity(identity: VisualIdentity): void {
    try {
      const merged: VisualIdentity = {
        ...initialVisualIdentity,
        ...identity,
        colors: {
          ...DEFAULT_COLORS,
          ...(initialVisualIdentity.colors || {}),
          ...(identity.colors || {})
        },
        typography: {
          ...DEFAULT_TYPOGRAPHY,
          ...(initialVisualIdentity.typography || {}),
          ...(identity.typography || {})
        }
      };
      localStorage.setItem(STORAGE_KEYS.IDENTITY, JSON.stringify(merged));
      applyThemeColors(merged.colors);
      applyThemeTypography(merged.typography);
      window.dispatchEvent(new Event('portal_data_updated'));
    } catch (e) {
      console.error('Failed to save visual identity', e);
    }
  },

  // Facebook Config
  getFacebookConfig(): FacebookConfig {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.FB_CONFIG);
      if (data) return JSON.parse(data);
    } catch (e) {
      console.error('Failed to load FB config', e);
    }
    this.saveFacebookConfig(initialFacebookConfig);
    return initialFacebookConfig;
  },

  saveFacebookConfig(config: FacebookConfig): void {
    try {
      localStorage.setItem(STORAGE_KEYS.FB_CONFIG, JSON.stringify(config));
      window.dispatchEvent(new Event('portal_data_updated'));
    } catch (e) {
      console.error('Failed to save FB config', e);
    }
  },

  // Facebook Logs
  getFacebookLogs(): FacebookLog[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.FB_LOGS);
      if (data) return JSON.parse(data);
    } catch (e) {
      console.error('Failed to load FB logs', e);
    }
    return [
      {
        id: 'log-1',
        articleId: 'art-1',
        articleTitle: 'Congresso aprova novo marco da transição energética com foco em energias limpas',
        timestamp: '2026-09-11T09:32:00Z',
        status: 'success',
        message: 'Publicação realizada com sucesso na Página do Facebook.',
        facebookPostId: 'fb_post_99214481_01'
      }
    ];
  },

  addFacebookLog(log: Omit<FacebookLog, 'id'>): void {
    const logs = this.getFacebookLogs();
    const newLog: FacebookLog = {
      ...log,
      id: 'log-' + Date.now(),
    };
    logs.unshift(newLog);
    // Keep max 50 logs
    const trimmed = logs.slice(0, 50);
    try {
      localStorage.setItem(STORAGE_KEYS.FB_LOGS, JSON.stringify(trimmed));
      window.dispatchEvent(new Event('portal_data_updated'));
    } catch (e) {
      console.error('Failed to save FB log', e);
    }
  },

  clearFacebookLogs(): void {
    localStorage.removeItem(STORAGE_KEYS.FB_LOGS);
    window.dispatchEvent(new Event('portal_data_updated'));
  },

  // Site PopUp with Attached Image
  getSitePopup(): SitePopup {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.POPUP);
      if (data) {
        const parsed = JSON.parse(data);
        return {
          ...initialSitePopup,
          ...parsed,
        };
      }
    } catch (e) {
      console.error('Failed to load site popup from storage', e);
    }
    this.saveSitePopup(initialSitePopup);
    return initialSitePopup;
  },

  saveSitePopup(popup: Partial<SitePopup>): SitePopup {
    try {
      const current = this.getSitePopup();
      const updated: SitePopup = {
        ...current,
        ...popup,
        updatedAt: new Date().toISOString(),
      };
      localStorage.setItem(STORAGE_KEYS.POPUP, JSON.stringify(updated));
      window.dispatchEvent(new Event('portal_data_updated'));
      return updated;
    } catch (e) {
      console.error('Failed to save site popup', e);
      return initialSitePopup;
    }
  },

  // Business Guide (Guia Empresarial) Configuration
  getBusinessGuideConfig(): BusinessGuideConfig {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.BUSINESS_CONFIG);
      if (data) {
        return {
          ...initialBusinessGuideConfig,
          ...JSON.parse(data),
        };
      }
    } catch (e) {
      console.error('Failed to load business guide config', e);
    }
    this.saveBusinessGuideConfig(initialBusinessGuideConfig);
    return initialBusinessGuideConfig;
  },

  saveBusinessGuideConfig(config: Partial<BusinessGuideConfig>): BusinessGuideConfig {
    try {
      const current = this.getBusinessGuideConfig();
      const updated: BusinessGuideConfig = {
        ...current,
        ...config,
      };
      localStorage.setItem(STORAGE_KEYS.BUSINESS_CONFIG, JSON.stringify(updated));
      window.dispatchEvent(new Event('portal_data_updated'));
      return updated;
    } catch (e) {
      console.error('Failed to save business guide config', e);
      return initialBusinessGuideConfig;
    }
  },

  // Business Stores (Lojas do Guia)
  getBusinessStores(): BusinessStore[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.BUSINESS_STORES);
      if (data) {
        const parsed: BusinessStore[] = JSON.parse(data);
        return parsed;
      }
    } catch (e) {
      console.error('Failed to load business stores', e);
    }
    this.saveBusinessStores(initialBusinessStores);
    return initialBusinessStores;
  },

  saveBusinessStores(stores: BusinessStore[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.BUSINESS_STORES, JSON.stringify(stores));
      window.dispatchEvent(new Event('portal_data_updated'));
    } catch (e) {
      console.error('Failed to save business stores', e);
    }
  },

  saveBusinessStore(store: BusinessStore): void {
    const stores = this.getBusinessStores();
    const index = stores.findIndex(s => s.id === store.id);
    if (index >= 0) {
      stores[index] = store;
    } else {
      stores.unshift(store);
    }
    this.saveBusinessStores(stores);
  },

  deleteBusinessStore(id: string): void {
    const stores = this.getBusinessStores().filter(s => s.id !== id);
    this.saveBusinessStores(stores);
    // Also delete associated products
    const products = this.getBusinessProducts().filter(p => p.businessId !== id);
    this.saveBusinessProducts(products);
  },

  // Business Products / Services (Produtos e Serviços)
  getBusinessProducts(businessId?: string): BusinessProductService[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.BUSINESS_PRODUCTS);
      if (data) {
        const parsed: BusinessProductService[] = JSON.parse(data);
        if (businessId) {
          return parsed.filter(p => p.businessId === businessId);
        }
        return parsed;
      }
    } catch (e) {
      console.error('Failed to load business products', e);
    }
    this.saveBusinessProducts(initialBusinessProducts);
    if (businessId) {
      return initialBusinessProducts.filter(p => p.businessId === businessId);
    }
    return initialBusinessProducts;
  },

  saveBusinessProducts(products: BusinessProductService[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.BUSINESS_PRODUCTS, JSON.stringify(products));
      window.dispatchEvent(new Event('portal_data_updated'));
    } catch (e) {
      console.error('Failed to save business products', e);
    }
  },

  saveBusinessProduct(product: BusinessProductService): void {
    const products = this.getBusinessProducts();
    const index = products.findIndex(p => p.id === product.id);
    if (index >= 0) {
      products[index] = product;
    } else {
      products.unshift(product);
    }
    this.saveBusinessProducts(products);
  },

  deleteBusinessProduct(id: string): void {
    const products = this.getBusinessProducts().filter(p => p.id !== id);
    this.saveBusinessProducts(products);
  },

  // Admin Users Management (Multi-user system)
  getAdminUsers(): AdminUser[] {
    const defaultUsers: AdminUser[] = [
      {
        id: 'user-daniel-1995',
        username: '@Daniel1995',
        password: '1010',
        name: 'Daniel',
        role: 'admin',
        createdAt: new Date().toISOString(),
        isDefault: true,
      }
    ];

    try {
      const data = localStorage.getItem(STORAGE_KEYS.ADMIN_USERS);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Normalize Daniel1995 to @Daniel1995 if present
          let hasDaniel = false;
          const normalized = parsed.map(u => {
            const raw = (u.username || '').trim();
            const lowerNoAt = raw.toLowerCase().replace(/^@/, '');
            if (lowerNoAt === 'daniel1995') {
              hasDaniel = true;
              return {
                ...u,
                username: '@Daniel1995',
                password: u.password || '1010',
                isDefault: true,
              };
            }
            return u;
          });

          if (!hasDaniel) {
            normalized.unshift(defaultUsers[0]);
          }
          this.saveAdminUsersList(normalized);
          return normalized;
        }
      }
    } catch (e) {
      console.error('Failed to load admin users', e);
    }

    this.saveAdminUsersList(defaultUsers);
    return defaultUsers;
  },

  saveAdminUsersList(users: AdminUser[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.ADMIN_USERS, JSON.stringify(users));
      window.dispatchEvent(new Event('portal_admin_users_updated'));
    } catch (e) {
      console.error('Failed to save admin users list', e);
    }
  },

  saveAdminUser(userData: { id?: string; username: string; password: string; name?: string; role?: 'admin' | 'editor' }): { success: boolean; user?: AdminUser; message: string } {
    const users = this.getAdminUsers();
    let rawUsername = userData.username.trim();
    // Ensure consistent formatting: if user didn't start with @, add it or allow it
    const cleanUsername = rawUsername.startsWith('@') ? rawUsername : `@${rawUsername}`;
    const cleanPassword = userData.password.trim();
    const cleanName = (userData.name || cleanUsername.replace(/^@/, '')).trim();

    if (!cleanUsername || cleanUsername === '@') {
      return { success: false, message: 'O nome de usuário não pode ficar vazio.' };
    }
    if (!cleanPassword) {
      return { success: false, message: 'A senha não pode ficar vazia.' };
    }

    // Check duplicate username (case-insensitive and ignoring @)
    const normClean = cleanUsername.toLowerCase().replace(/^@/, '');
    const duplicate = users.find(u => {
      const uNorm = (u.username || '').toLowerCase().replace(/^@/, '');
      return uNorm === normClean && u.id !== userData.id;
    });

    if (duplicate) {
      return { success: false, message: `Já existe um usuário com o nome "${cleanUsername}". Escolha outro nome.` };
    }

    if (userData.id) {
      // Edit existing
      const index = users.findIndex(u => u.id === userData.id);
      if (index === -1) {
        return { success: false, message: 'Usuário não encontrado para edição.' };
      }
      users[index] = {
        ...users[index],
        username: cleanUsername,
        password: cleanPassword,
        name: cleanName,
        role: userData.role || users[index].role || 'admin',
        updatedAt: new Date().toISOString()
      };
      this.saveAdminUsersList(users);
      return { success: true, user: users[index], message: 'Usuário atualizado com sucesso!' };
    } else {
      // Create new
      const newUser: AdminUser = {
        id: 'user-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
        username: cleanUsername,
        password: cleanPassword,
        name: cleanName,
        role: userData.role || 'admin',
        createdAt: new Date().toISOString()
      };
      users.push(newUser);
      this.saveAdminUsersList(users);
      return { success: true, user: newUser, message: 'Novo usuário criado com sucesso!' };
    }
  },

  deleteAdminUser(userId: string): { success: boolean; message: string } {
    const users = this.getAdminUsers();
    
    // If only one user or deleting the last user, recreate default safety user @Daniel1995
    if (users.length <= 1 || (users.length === 1 && users[0].id === userId)) {
      const defaultUsers: AdminUser[] = [
        {
          id: 'user-daniel-1995',
          username: '@Daniel1995',
          password: '1010',
          name: 'Daniel',
          role: 'admin',
          createdAt: new Date().toISOString(),
          isDefault: true,
        }
      ];
      this.saveAdminUsersList(defaultUsers);
      return { success: true, message: 'Usuário removido. As credenciais padrão de segurança (@Daniel1995 / 1010) foram restauradas.' };
    }

    const filtered = users.filter(u => u.id !== userId);
    if (filtered.length === users.length) {
      return { success: false, message: 'Usuário não encontrado para exclusão.' };
    }
    this.saveAdminUsersList(filtered);
    return { success: true, message: 'Usuário excluído com sucesso.' };
  },

  verifyAdminUser(usernameInput: string, passwordInput: string): { success: boolean; user?: AdminUser; message: string } {
    const users = this.getAdminUsers();
    const rawClean = usernameInput.trim().toLowerCase();
    const cleanNoAt = rawClean.replace(/^@/, '');
    const cleanPassword = passwordInput.trim();

    // Universal matching: match with @ or without @, case-insensitive
    const matchedUser = users.find(u => {
      const uRaw = (u.username || '').trim().toLowerCase();
      const uNoAt = uRaw.replace(/^@/, '');
      return uRaw === rawClean || uNoAt === cleanNoAt;
    });

    // Hard fallback for safety login @Daniel1995 / 1010
    if (!matchedUser && (cleanNoAt === 'daniel1995') && cleanPassword === '1010') {
      const defaultDaniel: AdminUser = {
        id: 'user-daniel-1995',
        username: '@Daniel1995',
        password: '1010',
        name: 'Daniel',
        role: 'admin',
        createdAt: new Date().toISOString(),
        isDefault: true,
      };
      this.setCurrentAdminUser(defaultDaniel);
      return { success: true, user: defaultDaniel, message: 'Login autorizado com sucesso!' };
    }

    if (!matchedUser) {
      return { success: false, message: 'Usuário não encontrado. Verifique a digitação.' };
    }

    if (matchedUser.password !== cleanPassword) {
      return { success: false, message: 'Senha incorreta para este usuário.' };
    }

    // Save as current user session
    this.setCurrentAdminUser(matchedUser);
    return { success: true, user: matchedUser, message: 'Login autorizado com sucesso!' };
  },

  getCurrentAdminUser(): AdminUser | null {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
      if (data) {
        return JSON.parse(data);
      }
    } catch (e) {
      console.error('Failed to get current admin user', e);
    }
    const users = this.getAdminUsers();
    return users[0] || null;
  },

  setCurrentAdminUser(user: AdminUser | null): void {
    try {
      if (user) {
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
      } else {
        localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
      }
    } catch (e) {
      console.error('Failed to set current admin user', e);
    }
  },

  resetDefaultAdminUsers(): AdminUser[] {
    const defaultUsers: AdminUser[] = [
      {
        id: 'user-daniel-1995',
        username: '@Daniel1995',
        password: '1010',
        name: 'Daniel',
        role: 'admin',
        createdAt: new Date().toISOString(),
        isDefault: true,
      }
    ];
    this.saveAdminUsersList(defaultUsers);
    this.setCurrentAdminUser(defaultUsers[0]);
    return defaultUsers;
  },

  // Legacy Admin Credentials Management (compatibility layer)
  getAdminCredentials(): AdminCredentials {
    const users = this.getAdminUsers();
    const first = users[0];
    return {
      email: first ? first.username : '@Daniel1995',
      password: first ? first.password : '1010',
      updatedAt: first ? first.updatedAt || first.createdAt : new Date().toISOString()
    };
  },

  saveAdminCredentials(creds: AdminCredentials): void {
    this.saveAdminUser({
      username: creds.email,
      password: creds.password,
      name: 'Administrador'
    });
  },

  verifyAdminCredentials(input: string, passwordInput: string): boolean {
    const result = this.verifyAdminUser(input, passwordInput);
    return result.success;
  },

  resetAdminCredentials(): AdminCredentials {
    this.resetDefaultAdminUsers();
    return {
      email: 'Daniel1995',
      password: '1010',
      updatedAt: new Date().toISOString()
    };
  },

  // Reset to original demo content
  resetAllToDefault(): void {
    this.saveArticles(initialArticles);
    this.saveCategories(initialCategories);
    this.saveBanners(initialBanners);
    this.saveVisualIdentity(initialVisualIdentity);
    this.saveFacebookConfig(initialFacebookConfig);
    this.saveSitePopup(initialSitePopup);
    this.saveBusinessGuideConfig(initialBusinessGuideConfig);
    this.saveBusinessStores(initialBusinessStores);
    this.saveBusinessProducts(initialBusinessProducts);
    this.clearFacebookLogs();
  }
};
