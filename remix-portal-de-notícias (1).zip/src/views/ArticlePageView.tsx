import React, { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Article, Category, Banner } from '../types';
import { ArticleView } from '../components/ArticleView';
import { slugify } from '../utils/navigation';

interface ArticlePageViewProps {
  articles: Article[];
  categories: Category[];
  banners: Banner[];
}

export const ArticlePageView: React.FC<ArticlePageViewProps> = ({
  articles,
  categories,
  banners,
}) => {
  const params = useParams<{ category?: string; categorySlug?: string; articleSlug?: string; slug?: string }>();
  const publishedArticles = articles.filter(a => a.status === 'published');
  const sidebarBanners = banners.filter(b => b.position === 'sidebar' && b.active);

  // Target identifier prioritized by articleSlug / slug, then single param
  const targetSlug = (params.articleSlug || params.slug || params.categorySlug || params.category || '').toLowerCase().trim();

  // Match article by slug, normalized title, or id
  const article = publishedArticles.find(a => 
    (a.slug && a.slug.toLowerCase() === targetSlug) ||
    slugify(a.title) === targetSlug ||
    a.id.toLowerCase() === targetSlug
  ) || articles.find(a => 
    (a.slug && a.slug.toLowerCase() === targetSlug) ||
    slugify(a.title) === targetSlug ||
    a.id.toLowerCase() === targetSlug
  );

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (article) {
      document.title = `${article.title} - Portal Goioerê é Assim`;
    }
    return () => {
      document.title = 'Portal Goioerê é Assim';
    };
  }, [article]);

  if (!article) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <div className="bg-white rounded-2xl border border-slate-200 p-8 sm:p-12 shadow-xs">
          <span className="text-4xl mb-4 block">📰</span>
          <h1 className="text-2xl font-bold text-slate-900 mb-2">Matéria não encontrada</h1>
          <p className="text-sm text-slate-600 mb-6 max-w-md mx-auto">
            A notícia que você está procurando pode ter sido alterada, movida ou não está mais disponível.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link
              to="/noticias"
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors"
            >
              Ver todas as notícias
            </Link>
            <Link
              to="/"
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
            >
              Voltar ao Início
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ArticleView
      article={article}
      allArticles={publishedArticles}
      categories={categories}
      banners={sidebarBanners}
    />
  );
};
