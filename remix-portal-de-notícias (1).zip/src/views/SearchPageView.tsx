import React from 'react';
import { useSearchParams } from 'react-router-dom';
import { Article, Category } from '../types';
import { SearchResults } from '../components/SearchResults';

interface SearchPageViewProps {
  articles: Article[];
  categories: Category[];
}

export const SearchPageView: React.FC<SearchPageViewProps> = ({
  articles,
  categories,
}) => {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';

  return (
    <SearchResults
      initialQuery={query}
      articles={articles}
      categories={categories}
    />
  );
};
