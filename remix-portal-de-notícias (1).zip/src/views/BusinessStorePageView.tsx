import React, { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { BusinessStore, BusinessProductService } from '../types';
import { BusinessMinisite } from '../components/business/BusinessMinisite';
import { Store, ArrowLeft } from 'lucide-react';

interface BusinessStorePageViewProps {
  stores: BusinessStore[];
  products: BusinessProductService[];
}

export const BusinessStorePageView: React.FC<BusinessStorePageViewProps> = ({
  stores = [],
  products = [],
}) => {
  const { storeSlug } = useParams<{ storeSlug: string }>();

  const currentStore = stores.find(
    s => (s.slug && s.slug.toLowerCase() === storeSlug?.toLowerCase()) ||
         s.id.toLowerCase() === storeSlug?.toLowerCase()
  ) || null;

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (currentStore) {
      document.title = `${currentStore.name} - Guia Empresarial - Portal Goioerê é Assim`;
    }
    return () => {
      document.title = 'Portal Goioerê é Assim';
    };
  }, [currentStore]);

  if (!currentStore) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <div className="bg-white rounded-2xl border border-slate-200 p-8 sm:p-12 shadow-xs">
          <Store className="w-12 h-12 text-slate-400 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-slate-900 mb-2">Empresa não encontrada</h1>
          <p className="text-sm text-slate-600 mb-6 max-w-md mx-auto">
            Não localizamos os dados deste estabelecimento ou o link pode ter expirado.
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Link
              to="/guia-empresarial"
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar ao Guia Empresarial</span>
            </Link>
            <Link
              to="/"
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors"
            >
              Ir para a Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const storeProducts = products.filter(p => p.businessId === currentStore.id);

  return (
    <BusinessMinisite
      store={currentStore}
      products={storeProducts}
    />
  );
};
