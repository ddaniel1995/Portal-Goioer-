import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { BusinessGuideConfig, BusinessStore } from '../types';
import { BusinessDirectory } from '../components/business/BusinessDirectory';
import { getStoreUrl } from '../utils/navigation';

interface BusinessGuidePageViewProps {
  config: BusinessGuideConfig;
  stores: BusinessStore[];
}

export const BusinessGuidePageView: React.FC<BusinessGuidePageViewProps> = ({
  config,
  stores,
}) => {
  const navigate = useNavigate();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    document.title = 'Guia Empresarial - Portal Goioerê é Assim';
    return () => {
      document.title = 'Portal Goioerê é Assim';
    };
  }, []);

  return (
    <BusinessDirectory
      config={config}
      stores={stores}
      onSelectStore={(storeSlug) => {
        navigate(getStoreUrl(storeSlug));
      }}
      onGoHome={() => {
        navigate('/');
      }}
    />
  );
};
